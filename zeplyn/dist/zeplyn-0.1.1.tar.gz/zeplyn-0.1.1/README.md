# Zeplyn

## Usage

Zeplyn allows to you release python package fastly and easily in one command: 

```zeplyn publish```

You should run that command in your command prompt in the folder directory where you want to put your package

Zeplyn also have a ```zeplyn create``` command which automatically create a readme file, a setup.py file and a src folder where your package's code is going to be stored.

Full documentation here : https://github.com/ssantoshp/zeplyn